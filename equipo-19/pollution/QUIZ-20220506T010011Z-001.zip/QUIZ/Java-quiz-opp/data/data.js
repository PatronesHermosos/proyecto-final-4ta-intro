export const data = [
    {
      question: "cuales son los efectos producidos por la deforestacion?",
      choices: ["cambio climatico, extincion de especies y suelos no viables para la vegetacion", "cambio climatico, descongelamiento de los polos e inundaciones", "no hay efectos", " 1 y 2 opcion son correctas"],
      answer: "cambio climatico, extincion de especies y suelos no viables para la vegetacion",
    },
    {
      question: "El reciclaje es parte de la solucion a esta problematica",
      choices: ["tal vez", "Si", "No",],
      answer: "Si",
    },
    {
      question: "la deforestacion puede se sancionada si se hace de forma ilegal?",
      choices: ["Si", "no", ],
      answer: "Si",
    },
  ];
  